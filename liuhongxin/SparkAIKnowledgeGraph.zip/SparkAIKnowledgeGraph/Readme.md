#页面框架说明
##kg-left
包含Keyword的搜素次数统计信息，以及Top10的柱状图表
##chartdiv
未搜索关键字时，关键字转动（球状动画）
##themes
切换主题