#include "dimmwitted.h"

// a simple main that delegates to dw() to ease test with gtest
int main(int argc, char *argv[]) { return dd::dw(argc, argv); }
