# DimmWitted tests

## Running all tests

```bash
bats *.bats
```

## End to end test directories

### Factor graph TSV format

See [text_format.md](../doc/text_format.md)

