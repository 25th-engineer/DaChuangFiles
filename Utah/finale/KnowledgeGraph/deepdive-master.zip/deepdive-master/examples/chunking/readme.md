# Text chunking example

STALE: See the [page in the documentation](../../doc/example-chunking.md) for full detail.

NEW!!! (July 2016): Added word embedding features (Senna) for demonstration.

With 2K training words, it doesn't improve the quality though...
- Tried Glove and reg_param tuning to no avail.
- Maybe the distributional semantics of words cannot patch the remaining errors.
- Or maybe it'll make a difference on a larger training set.
