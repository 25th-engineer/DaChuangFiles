# Spouse Example for DeepDive Tutorial

See the [DeepDive tutorial in the documentation](../../doc/example-spouse.md) for full detail.
