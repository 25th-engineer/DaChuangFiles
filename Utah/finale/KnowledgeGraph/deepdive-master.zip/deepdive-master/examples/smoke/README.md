# Simple DeepDive Example: Smoke Example

See the [documentation about this simple example](../../doc/example-smoke.md) for more detail.
