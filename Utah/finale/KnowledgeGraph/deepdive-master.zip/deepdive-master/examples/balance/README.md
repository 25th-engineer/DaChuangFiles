# Balance example to illustrate different semantics

See Example 2.5 of [the VLDB 2015 paper](http://i.stanford.edu/hazy/papers/inc.pdf) for full detail.

Linear semantics is not good.
