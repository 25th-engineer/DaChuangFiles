# DeepDive Application Template

This directory contains a skeleton for a new DeepDive application.
See [DeepDive's documentation on application layout](http://deepdive.stanford.edu/deepdiveapp) for full detail.
