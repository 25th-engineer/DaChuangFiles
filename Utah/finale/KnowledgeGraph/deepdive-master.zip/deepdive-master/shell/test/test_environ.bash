#!/usr/bin/env bash
# Unit tests for DeepDive shell
# Usage: load test_environ  # from .bats files on the same directory

load ../../test/test_environ
