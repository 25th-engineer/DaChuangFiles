#!/usr/bin/env bash
# Unit tests for DeepDive runner
# Usage: load test_environ  # from .bats files typically on the same directory

load ../../test/test_environ
