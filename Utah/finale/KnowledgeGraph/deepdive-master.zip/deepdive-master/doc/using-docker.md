---
layout: default
title: Using DeepDive in Docker containers
---

<br><todo>

- This is very popular question, so we should at least leave some hints after trying something out.
- Usually people have trouble connecting PostgreSQL instance with the DeepDive instance itself.

</todo>
